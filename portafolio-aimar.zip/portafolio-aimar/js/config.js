/* ═══════════════════════════════════════════════════════
   CONFIGURACIÓN — rellena estos dos valores con los datos
   de tu proyecto de Supabase (Settings → API):
   · Project URL  → SUPABASE_URL
   · anon public  → SUPABASE_ANON_KEY
   Mientras estén vacíos, la web funciona en MODO DEMO con
   fotos de prueba y el panel de administración desactivado.
   ═══════════════════════════════════════════════════════ */

const SUPABASE_URL = "";        // p. ej. "https://abcdefgh.supabase.co"
const SUPABASE_ANON_KEY = "";   // p. ej. "eyJhbGciOiJIUzI1NiIs..."

/* Nombre del bucket de Storage donde se guardan las imágenes */
const BUCKET = "fotos";

/* Datos del propietario que se muestran en la interfaz */
const PERFIL = {
  nombre: "Aimar Merchán",
  subtitulo: "Fotógrafo · archivo expuesto",
  lema: "Nada en venta — todo a la vista",
};
